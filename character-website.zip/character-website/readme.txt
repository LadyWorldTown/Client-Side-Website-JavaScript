To run from terminal, beginning in this folder, input the following commands:
cd Client-Side
node app.js

Contributors: 
Kaylie Howard - Implemented client-side architecture, CSS, and HTML
Hayes Young - Implemented Favorites API
Tierra Anthony - Implemented Filters API

For more specific information regarding contributions, see GitHub: 
https://github.com/howardks/DistWebFinal 
